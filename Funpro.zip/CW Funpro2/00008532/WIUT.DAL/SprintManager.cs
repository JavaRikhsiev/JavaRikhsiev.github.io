﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlServerCe;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WIUT.DAL
{
    public class SprintManager : DbManager
    {
        public void Create(Sprint c)
        {
            var connection = Connection;
            try
            {
                var sql = $"INSERT INTO sp_sprint_8532 (sp_name_8532, sp_date_8532, sp_no_of_developers_8532, sp_status_8532) " +
                    $"VALUES ('{c.Name}', '{c.Date:yyyy-MM-dd}', {c.NoOfDevelopers}, '{c.Status}')";
                var command = new SqlCeCommand(sql, connection);
                connection.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }

            }

        }

        public void Update(Sprint c)
        {
            var connection = Connection;
            try
            {
                var sql = $"UPDATE sp_sprint_8532 SET sp_name_8532, sp_date_8532, sp_no_of_developers_8532, " +
                    $"sp_status_8532 = '{c.Name}', '{c.Date}', '{c.NoOfDevelopers}', '{c.Status}' WHERE sp_id_8532 = {c.Id}";
                var command = new SqlCeCommand(sql, connection);
                connection.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }
            }
        }

        public void Delete(int id)
        {
            var connection = Connection;
            try
            {
                var sql = $"DELETE FROM sp_sprint_8532 WHERE sp_id_8532 = {id}";
                var command = new SqlCeCommand(sql, connection);
                connection.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }
            }
        }

        public Sprint GetById(int id)
        {
            var connection = Connection;
            try
            {
                var sql = $"SELECT sp_id_8532, sp_name_8532, sp_date_8532, sp_no_of_developers_8532, " +
                    $"sp_status_8532 FROM sp_sprint WHERE sp_id_8532 = {id}";
                var command = new SqlCeCommand(sql, connection);
                connection.Open();
                var reader = command.ExecuteReader();
                if (reader.Read())
                {
                    var c = new Sprint
                    {
                        Id = Convert.ToInt32(reader.GetValue(0)),
                        Name = Convert.ToString(reader.GetValue(1)),
                        Date = Convert.ToDateTime(reader.GetValue(2)),
                        NoOfDevelopers = Convert.ToInt32(reader.GetValue(3)),
                        Status = Convert.ToString(reader.GetValue(4))
                    };
                    return c;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }

            }

            return null;
        }

        public List<Sprint> GetAll()
        {
            var connection = Connection;
            var result = new List<Sprint>();
            try
            {
                var sql = "SELECT sp_id_8532, sp_name_8532, sp_date_8532, sp_no_of_developers_8532, sp_status_8532 FROM sp_sprint_8532";
                var command = new SqlCeCommand(sql, connection);
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    var c = new Sprint
                    {
                        Id = Convert.ToInt32(reader.GetValue(0)),
                        Name = Convert.ToString(reader.GetValue(1)),
                        Date = Convert.ToDateTime(reader.GetValue(2)),
                        NoOfDevelopers = Convert.ToInt32(reader.GetValue(3)),
                        Status = Convert.ToString(reader.GetValue(4))
                    };
                    result.Add(c);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }

            }

            return result;
        }
    }
}
