﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WIUT.DAL;

namespace _00008532
{
    public partial class SprintEditForm : Form
    {
        public SprintEditForm()
        {
            InitializeComponent();
        }

        private void SprintEditForm_Load(object sender, EventArgs e)
        {

        }

        public Sprint Sprint { get; set; }

        public FormMode Mode { get; set; }

        public void CreateNewSprint()
        {
            Mode = FormMode.CreateNew;
            Sprint = new Sprint();
            InitializeControls();
            MdiParent = MyForms.GetForm<ParentForm>();
            Show();
        }

        public void UpdateSprint(Sprint sprint)
        {
            Mode = FormMode.Update;
            Sprint = sprint;
            InitializeControls();
            ShowSprintInControls();
            MdiParent = MyForms.GetForm<ParentForm>();
            Show();
        }

        private void InitializeControls()
        {
        }

        private void ShowSprintInControls()
        {
            tbx.Text = Sprint.Name;
            tbxStatus.Text = Sprint.Status;
           numDev.Value = Sprint.NoOfDevelopers;
            dtpDate.Value = Sprint.Date;
       

           
        }

        private void GrabUserInput()
        {
            Sprint.Name = tbx.Text;
            Sprint.Date = dtpDate.Value;
            Sprint.Status = tbxStatus.Text;
            Sprint.NoOfDevelopers = (int)numDev.Value;
           
           
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //this codes is for trigger validation 
            try
            {
                GrabUserInput();
                var manager = new SprintManager();
                if (Mode == FormMode.CreateNew)
                    manager.Create(Sprint);
                else
                    manager.Update(Sprint);

                MyForms.GetForm<SprintListForm>().LoadData();
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

    }
}

