﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WIUT.DAL;

namespace _00008532
{
    public partial class SprintListForm : Form
    {
        public SprintListForm()
        {
            InitializeComponent();
        }

        private void SprintListForm_Load(object sender, EventArgs e)
        {
            MdiParent = MyForms.GetForm<ParentForm>();
            LoadData();
        }
        public void LoadData()
        {
            dgv.DataMember = "";
            dgv.DataSource = null;
            dgv.DataSource = new SprintList().GetAllSprints();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnSort_Click(object sender, EventArgs e)
        {
            if (cbxSort.SelectedIndex < 0)
                MessageBox.Show("Select an attribute to sort by");
            else
            {
                

                dgv.DataMember = "";
                dgv.DataSource = null;


            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
           
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            new SprintEditForm().CreateNewSprint();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dgv.SelectedRows.Count == 0)
                MessageBox.Show("Please select a Sprint");
            else
            {
                var c = (Sprint)dgv.SelectedRows[0].DataBoundItem;
                new SprintEditForm().UpdateSprint(c);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgv.SelectedRows.Count == 0)
                MessageBox.Show("Please select a Sprint");
            else
            {
                var c = (Sprint)dgv.SelectedRows[0].DataBoundItem;
                new SprintManager().Delete(c.Id);
                LoadData();
            }
        }
    }
}
