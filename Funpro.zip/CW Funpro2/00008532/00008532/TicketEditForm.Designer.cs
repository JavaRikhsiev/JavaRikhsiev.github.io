﻿namespace _00008532
{
    partial class TicketEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnCancel = new System.Windows.Forms.Button();
            this.tbx = new System.Windows.Forms.TextBox();
            this.Summary = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tbxDescription = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cbxPriority = new System.Windows.Forms.ComboBox();
            this.cbxStatus = new System.Windows.Forms.ComboBox();
            this.Sprint_Id = new System.Windows.Forms.Label();
            this.cbxSprintId = new System.Windows.Forms.ComboBox();
            this.sprintBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nudEstimation = new System.Windows.Forms.NumericUpDown();
            this.sprintListBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sprintBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.sprintBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEstimation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprintListBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprintBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(70, 234);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // tbx
            // 
            this.tbx.Location = new System.Drawing.Point(85, 52);
            this.tbx.Name = "tbx";
            this.tbx.Size = new System.Drawing.Size(141, 20);
            this.tbx.TabIndex = 0;
            // 
            // Summary
            // 
            this.Summary.AutoSize = true;
            this.Summary.Location = new System.Drawing.Point(29, 55);
            this.Summary.Name = "Summary";
            this.Summary.Size = new System.Drawing.Size(50, 13);
            this.Summary.TabIndex = 2;
            this.Summary.Text = "Summary";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(151, 234);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Description";
            // 
            // tbxDescription
            // 
            this.tbxDescription.Location = new System.Drawing.Point(85, 78);
            this.tbxDescription.Name = "tbxDescription";
            this.tbxDescription.Size = new System.Drawing.Size(141, 20);
            this.tbxDescription.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Estimation";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(41, 133);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Priority";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(44, 162);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Status";
            // 
            // cbxPriority
            // 
            this.cbxPriority.FormattingEnabled = true;
            this.cbxPriority.Items.AddRange(new object[] {
            "Showstopper",
            "High",
            "Normal",
            "Low"});
            this.cbxPriority.Location = new System.Drawing.Point(85, 130);
            this.cbxPriority.Name = "cbxPriority";
            this.cbxPriority.Size = new System.Drawing.Size(141, 21);
            this.cbxPriority.TabIndex = 5;
            // 
            // cbxStatus
            // 
            this.cbxStatus.FormattingEnabled = true;
            this.cbxStatus.Items.AddRange(new object[] {
            "Backlog",
            "Planned",
            "Done"});
            this.cbxStatus.Location = new System.Drawing.Point(85, 159);
            this.cbxStatus.Name = "cbxStatus";
            this.cbxStatus.Size = new System.Drawing.Size(141, 21);
            this.cbxStatus.TabIndex = 6;
            // 
            // Sprint_Id
            // 
            this.Sprint_Id.AutoSize = true;
            this.Sprint_Id.Location = new System.Drawing.Point(33, 192);
            this.Sprint_Id.Name = "Sprint_Id";
            this.Sprint_Id.Size = new System.Drawing.Size(48, 13);
            this.Sprint_Id.TabIndex = 8;
            this.Sprint_Id.Text = "Sprint ID";
            // 
            // cbxSprintId
            // 
            this.cbxSprintId.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.sprintBindingSource1, "Name", true));
            this.cbxSprintId.DataSource = this.sprintBindingSource;
            this.cbxSprintId.DisplayMember = "Name";
            this.cbxSprintId.FormattingEnabled = true;
            this.cbxSprintId.Location = new System.Drawing.Point(85, 189);
            this.cbxSprintId.Name = "cbxSprintId";
            this.cbxSprintId.Size = new System.Drawing.Size(141, 21);
            this.cbxSprintId.TabIndex = 9;
            this.cbxSprintId.ValueMember = "Id";
            // 
            // sprintBindingSource
            // 
            this.sprintBindingSource.DataSource = typeof(WIUT.DAL.Sprint);
            // 
            // nudEstimation
            // 
            this.nudEstimation.Location = new System.Drawing.Point(85, 105);
            this.nudEstimation.Name = "nudEstimation";
            this.nudEstimation.Size = new System.Drawing.Size(141, 20);
            this.nudEstimation.TabIndex = 10;
            // 
            // sprintListBindingSource
            // 
            this.sprintListBindingSource.DataSource = typeof(WIUT.DAL.SprintList);
            // 
            // sprintBindingSource1
            // 
            this.sprintBindingSource1.DataSource = typeof(WIUT.DAL.Sprint);
            // 
            // TicketEditForm
            // 
            this.AcceptButton = this.btnSave;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(280, 291);
            this.Controls.Add(this.nudEstimation);
            this.Controls.Add(this.cbxSprintId);
            this.Controls.Add(this.Sprint_Id);
            this.Controls.Add(this.cbxStatus);
            this.Controls.Add(this.cbxPriority);
            this.Controls.Add(this.tbxDescription);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Summary);
            this.Controls.Add(this.tbx);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCancel);
            this.Name = "TicketEditForm";
            this.Text = "TicketEditForm";
            this.Load += new System.EventHandler(this.TicketEditForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sprintBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEstimation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprintListBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprintBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox tbx;
        private System.Windows.Forms.Label Summary;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbxDescription;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbxPriority;
        private System.Windows.Forms.ComboBox cbxStatus;
        private System.Windows.Forms.Label Sprint_Id;
        private System.Windows.Forms.ComboBox cbxSprintId;
        private System.Windows.Forms.NumericUpDown nudEstimation;
        private System.Windows.Forms.BindingSource sprintBindingSource;
        private System.Windows.Forms.BindingSource sprintListBindingSource;
        private System.Windows.Forms.BindingSource sprintBindingSource1;
    }
}