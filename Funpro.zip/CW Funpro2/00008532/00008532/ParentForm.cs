﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WIUT.DAL;

namespace _00008532
{
    public partial class ParentForm : Form
    {
        public ParentForm()
        {
            InitializeComponent();
        }

        private void allSprintToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //those codes are to show SprintListForm via MyForms.cs
            MyForms.GetForm<SprintListForm>().Show();
        }

        private void sprintToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void ParentForm_Load(object sender, EventArgs e)
        {
            //MessageBox.Show(new SprintList().GetAllSprints().Count.ToString());

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //this codes implomented to exit (not close) from the form 
            Application.Exit();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //this codes implomented using in order to open form namely AboutForm
            var about = new AboutForm();
            about.ShowDialog();
        }

        private void allTicketsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //those codes are to make appear TicketListForm via MyForms.cs
            MyForms.GetForm<TicketListForm>().Show();
        }

        private void newSprintToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //this codes implomented in order to open form namely SprintEditForm
            new SprintEditForm().CreateNewSprint();
        }

        private void newTicketsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //this codes implomented in order to open form namely TicketEditForm
            var form = new TicketEditForm();
            form.ShowDialog();
        }
    }
}
