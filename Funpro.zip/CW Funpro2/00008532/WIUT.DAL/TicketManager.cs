﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlServerCe;


namespace WIUT.DAL
{
   public class TicketManager : DbManager
    {
        public void Create(Ticket c)
        {
            var connection = Connection;
            try
            {
                var sql = $"INSERT INTO ti_ticket_8532 (ti_summery_8532, ti_description_8532, ti_estimation_8532, ti_priority_8532, ti_status_8532, ti_sprint_id_8532) " +
                    $"VALUES ('{c.Summary}', '{c.Description}', '{c.Estimation}', '{c.Priority}', '{c.Status}', '{c.Sprint}')";
                var command = new SqlCeCommand(sql, connection);
                connection.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }

            }

        }

        public List<Ticket> GetAll()
        {
            var connection = Connection;
            var result = new List<Ticket>();
            try
            {
                var sql = "SELECT ti_id_8532, ti_summery_8532, ti_description_8532, ti_estimation_8532, ti_priority_8532, ti_status_8532, ti_sprint_id_8532 FROM ti_ticket_8532";
                var command = new SqlCeCommand(sql, connection);
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    var a = GetFromReader(reader);
                    result.Add(a);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }
            }

            return result;
        }

        public void Update(Ticket a)
        {
            var connection = Connection;
            try
            {
                var sql = $@"
UPDATE ti_ticket_8532 SET 
    ti_id_8532 = '{a.Id}', 
    ti_summery_8532 = '{a.Summary}', 
ti_description_8532 = '{a.Description}',
ti_estimation_8532 = '{a.Estimation}',
ti_priority_8532 = '{a.Priority}',
ti_status_8532 = '{a.Status}',
ti_sprint_id_8532 = '{a.Sprint}',
WHERE ti_id_8532 = {a.Id}";
                var command = new SqlCeCommand(sql, connection);
                connection.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }

            }
        }

        public void Delete(int id)
        {
            var connection = Connection;
            try
            {
                var sql = $"DELETE FROM ti_ticket_8532 WHERE ti_id_8532={id}";
                var command = new SqlCeCommand(sql, connection);
                connection.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }
            }
        }

        public Ticket GetById(int id)
        {
            var connection = Connection;
            try
            {
                var sql = $@"
SELECT ti_id_8532, ti_summery_8532, ti_description_8532, ti_estimation_8532, ti_priority_8532, ti_status_8532, ti_sprint_id_8532
FROM ti_ticket_8532

WHERE ID = {id}";
                var command = new SqlCeCommand(sql, connection);
                connection.Open();
                var reader = command.ExecuteReader();
                if (reader.Read())
                {
                    var a = GetFromReader(reader);
                    return a;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }
            }

            
            return null;
        }

        private Ticket GetFromReader(SqlCeDataReader reader)
        {
            var a = new Ticket
            {
                Id = Convert.ToInt32(reader.GetValue(0)),
                Summary = reader.GetValue(1).ToString(),
                Description = reader.GetValue(2).ToString(),
                Estimation = reader.GetValue(3).ToString(),
                Priority = reader.GetValue(4).ToString(),
                Status = reader.GetValue(5).ToString(),
                Sprint = new SprintManager().GetById(Convert.ToInt32(reader.GetValue(6)))
            };

            return a;
        }


    }
}
