﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WIUT.DAL;

namespace _00008532
{
    public partial class TicketEditForm : Form
    {
        public Ticket Ticket { get; set; }
     
        public FormMode Mode { get; set; }
        public void CreateNewTicket()
        {
            Mode = FormMode.CreateNew;
            Ticket = new Ticket();
            InitializeControls();
            MdiParent = MyForms.GetForm<ParentForm>();
            Show();
        }

        public void UpdateTicket(Ticket ticket)
        {
            Mode = FormMode.Update;
            Ticket = ticket;
            InitializeControls();
            ShowTicketInControls();
            MdiParent = MyForms.GetForm<ParentForm>();
            Show();
        }

        private void ShowTicketInControls()
        {
            tbx.Text = Ticket.Summary;
            tbxDescription.Text = Ticket.Description;
            nudEstimation.Text = Ticket.Estimation;
            cbxPriority.Text = Ticket.Priority;
            cbxStatus.Text = Ticket.Status;
            cbxSprintId.SelectedValue = Ticket.Sprint;

        }

        private void GrabUserInput()
        {
            Ticket.Summary = tbx.Text;
            Ticket.Description = tbxDescription.Text;
            Ticket.Estimation = nudEstimation.Text;
            Ticket.Priority = cbxPriority.Text;
            Ticket.Status = cbxStatus.Text;
            Ticket.Sprint = (Sprint)cbxSprintId.SelectedItem;

        }
        public TicketEditForm()
        {
            InitializeComponent();
        }

        private void InitializeControls()
        {
            
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //this codes is for trigger validation 
            try
            {
                GrabUserInput();
                var manager = new TicketManager();
                if (Mode == FormMode.CreateNew)
                    manager.Create(Ticket);
                else
                    manager.Update(Ticket);

                MyForms.GetForm<TicketListForm>().LoadData();
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void TicketEditForm_Load(object sender, EventArgs e)
        {

        }
    }
}
